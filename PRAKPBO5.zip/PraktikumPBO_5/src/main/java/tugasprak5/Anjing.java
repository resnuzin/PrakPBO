package tugasprak5;

public class Anjing extends Hewan{
    @Override
    public void tampilkanInfo(){
        super.tampilkanInfo();
        suaraHewan();
    }
    public void suaraHewan(){
        System.out.println("Aaauuuuuuuuuuuuuu");
    }
}

