package tugasprak5;

public class Hewan {
    String nama;
    String jenis;
    
    public void tampilkanInfo(){
        System.out.println("Nama Hewan "+nama);
        System.out.println("Jenis Hewan "+jenis);
    }
}
