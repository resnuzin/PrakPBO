package tugasprak5;

public class Kucing extends Hewan{
    
    @Override
    public void tampilkanInfo(){
        super.tampilkanInfo();
        suaraHewan();
    }
    public void suaraHewan(){
        System.out.println("Nyanyame nyanyaju nyanya do nyo nyarabi de nyakunyakuinanaku "
                + "nyanyahan nyanya dai nyannyaku nyarabete nyaganyagame");
    }
}
