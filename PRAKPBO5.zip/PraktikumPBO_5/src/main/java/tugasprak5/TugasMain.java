package tugasprak5;

public class TugasMain {

    public static void main(String[] args) {
        Anjing Dog = new Anjing();
        Dog.nama = "Swain";
        Dog.jenis = "Cihuahua";
        Dog.tampilkanInfo(); 
        
        Kucing Neko = new Kucing();
        Neko.nama = "Hanekawa";
        Neko.jenis = "Kucing Putih";
        Neko.tampilkanInfo();
    }
}
