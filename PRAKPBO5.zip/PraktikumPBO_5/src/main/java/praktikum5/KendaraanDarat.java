package praktikum5;

public class KendaraanDarat extends Kendaraan{
    
    @Override
    public void tampilkanInfo(){
        super.tampilkanInfo();
        System.out.println("Kendaraan Darat");
    }
}
