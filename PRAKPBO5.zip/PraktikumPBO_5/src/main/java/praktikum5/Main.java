package praktikum5;

public class Main {
    public static void main(String[] args) {
        Mobil Ban4 = new Mobil();
        Ban4.nama = "Porche";
        Ban4.kecepatan = 300;
        Ban4.JumlahPintu = 2;
        Ban4.tampilkanInfo();
        
        SepedaMotor motorBapak = new SepedaMotor();
        motorBapak.nama = "SupraX";
        motorBapak.kecepatan = 1000;
        motorBapak.JenisMesin = "4 Silinder";
        motorBapak.tampilkanInfo();
    }    
}
