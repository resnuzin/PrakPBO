package praktikum5;

public class Mobil extends KendaraanDarat{
    int JumlahPintu;
    
    @Override
    public void tampilkanInfo(){
        super.tampilkanInfo();
        System.out.println("Jumlah pintu "+JumlahPintu+ "\n");
    }
}
