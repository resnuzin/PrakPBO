package praktikum5;

public class SepedaMotor extends KendaraanDarat{
    String JenisMesin;
    
    @Override
    public void tampilkanInfo(){
        super.tampilkanInfo();
        System.out.println("Jenis Mesin "+ JenisMesin+ "\n");
    }
}
