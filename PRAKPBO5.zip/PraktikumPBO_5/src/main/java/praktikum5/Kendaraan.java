package praktikum5;

public class Kendaraan {
    String nama;
    int kecepatan;
    
    public void tampilkanInfo(){
        System.out.println("Nama Kendaraan " + nama);
        System.out.println("Kecepatan " + kecepatan + "km/jam");
    }
}
