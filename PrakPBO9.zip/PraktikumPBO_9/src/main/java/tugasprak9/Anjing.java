package tugasprak9;

public class Anjing extends Hewan{
    @Override
    void suara(){
        System.out.println("Anjing mengeluarkan suara: Guk Guk");
    }
}
