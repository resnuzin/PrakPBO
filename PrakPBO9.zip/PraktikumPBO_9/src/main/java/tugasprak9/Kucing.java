package tugasprak9;

public class Kucing extends Hewan{
    @Override
    void suara(){
        System.out.println("Kucing mengeluarkan suara: Meong");
    }
}
