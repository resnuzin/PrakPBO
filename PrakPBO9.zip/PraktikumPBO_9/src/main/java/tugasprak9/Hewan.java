package tugasprak9;

abstract class Hewan {
    abstract void suara();
}
