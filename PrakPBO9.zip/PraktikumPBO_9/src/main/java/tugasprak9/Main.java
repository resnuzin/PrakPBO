package tugasprak9;

public class Main {
    public static void main(String[] args) {
        Kucing mew = new Kucing();
        Anjing dogy = new Anjing();
        
        mew.suara();
        
        dogy.suara();
    }
    
}
