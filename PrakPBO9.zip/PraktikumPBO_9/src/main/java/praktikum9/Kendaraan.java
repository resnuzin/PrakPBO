package praktikum9;

abstract class Kendaraan {
    abstract void berjalan();
    
    void info(){
        System.out.println("Ini adalah kendaraan.");
    }
}
