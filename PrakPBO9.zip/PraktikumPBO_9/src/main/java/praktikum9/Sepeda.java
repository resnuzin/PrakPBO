package praktikum9;

public class Sepeda extends Kendaraan{
    @Override
    void berjalan(){
        System.out.println("Sepeda sedang berjalan dengan pelan.");
    }
}
