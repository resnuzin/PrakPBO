package praktikum9;

public class Main {
    public static void main(String[] args) {
        Kendaraan mobil = new Mobil();
        Kendaraan sepeda = new Sepeda();
        //Tidak dapat menambah objek dengan menggunakan kelas kendaraan
        //Karena kelas kendaraan adalah kelas abstract
        
        mobil.berjalan();
        mobil.info();
        
        sepeda.berjalan();
        sepeda.info();
        
    }
    
}
