package tugasPrak10;

public class Main {

    public static void main(String[] args) {
        Pembayaran elektronik = new Elektronik();
        System.out.println("Pajak yang Harus Dibayar : "+elektronik.hitungPajak(10000));
        
        Pembayaran makanan = new Makanan();
        System.out.println("Pajak yang Harus Dibayar : "+makanan.hitungPajak(30000));
    }
    
}
