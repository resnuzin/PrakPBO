package tugasPrak10;

public interface Pembayaran {
    double hitungPajak(double harga);
}
