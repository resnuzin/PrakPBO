package praktikum10;

public class Penjumlahan implements OperasiHitung{
    @Override
    public int hitung(int a, int b){
        return a + b;
    }
}
