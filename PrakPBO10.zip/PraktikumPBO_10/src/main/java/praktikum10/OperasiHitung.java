package praktikum10;

public interface OperasiHitung {
    int hitung(int a, int b);
}
