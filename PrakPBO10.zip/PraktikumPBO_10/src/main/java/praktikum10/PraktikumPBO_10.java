package praktikum10;

public class PraktikumPBO_10 {

    public static void main(String[] args) {
        OperasiHitung Penjumlahan = new Penjumlahan();
        System.out.println("Penjumlahan :"+Penjumlahan.hitung(12, 6));
        
        OperasiHitung Pengurangan = new Pengurangan();
        System.out.println("Pengurangan: "+Pengurangan.hitung(6, 3));
    }
}
