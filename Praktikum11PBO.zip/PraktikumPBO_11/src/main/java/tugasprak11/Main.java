package tugasprak11;

public class Main {
    
    public static void main(String[] args) {
        Pengarang pengarang1 = new Pengarang("Tite Kubo");
        Pengarang pengarang2 = new Pengarang("Masashi Kishimoto");
        Pengarang pengarang3 = new Pengarang("Reki Kawahara");
        
        Buku buku1 = new Buku("Bleach: Can't Fear Your Own World", pengarang1);
        Buku buku2 = new Buku("Sasuke Retsuden: The Uchiha Descendants and the Heavenly Stardust", pengarang2);
        Buku buku3 = new Buku("Mother's Rosario", pengarang3);
    
        Perpustakaan perpustakaan = new Perpustakaan();
        perpustakaan.tambahBuku(buku1);
        perpustakaan.tambahBuku(buku2);
        perpustakaan.tambahBuku(buku3);
        
        perpustakaan.infoPerpustakaan();
    }
}
