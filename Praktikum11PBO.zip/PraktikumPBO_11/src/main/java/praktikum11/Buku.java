package praktikum11;

public class Buku {
    private String judul;
    public Buku(String judul) {
        this.judul = judul;
    }
    public void infoBuku() {
        System.out.println("Judul Buku: " + judul);
    }
}
