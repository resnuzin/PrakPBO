package praktikum11;

public class Main {
    public static void main(String[] args) {
        Buku buku1 = new Buku("Ayah");
        Buku buku2 = new Buku("Bulan");
        Buku buku3 = new Buku("Komet");
        
        Perpustakaan perpustakaan = new Perpustakaan();
        perpustakaan.tambahBuku(buku1);
        perpustakaan.tambahBuku(buku2);
        perpustakaan.tambahBuku(buku3);
        
        System.out.println("List Buku Terlaris Minggu ini : ");
        perpustakaan.infoPerpustakaan();
        
        Anggota anggota1 = new Anggota("Kurosaki Ichigo");
        Anggota anggota2 = new Anggota("Gojou Satoru");
        Anggota anggota3 = new Anggota("Kirigaya Kazuto");
        
        Klub klub = new Klub("Klub Karakter Utama");
        klub.tambahAnggota(anggota1);
        klub.tambahAnggota(anggota2);
        klub.tambahAnggota(anggota3);
        
        System.out.println("\nInformasi Klub : ");
        klub.infoKlub();
    }
}
