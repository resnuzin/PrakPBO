
package com.mycompany.resnu.project1;

public class ResnuProject1 {
    public static void main(String[] args) {
        System.out.println("Nama : Resnu Mukti Ismail Hanif");
        System.out.println("NPM : 2310506012");
        System.out.println("Alamat : Jeruklegi,Cilacap");
        System.out.println("No_HP : 083131172812");
    }
}
